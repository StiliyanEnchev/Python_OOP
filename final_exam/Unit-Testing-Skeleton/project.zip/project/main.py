from project.social_media import SocialMedia

twitter = SocialMedia('Petar',
                              'Twitter',
                              10,
                              'Photos')


twitter._username = "Vector"
print(twitter._username)